package com.example.weather_app_assignment4;

public class XmlAdapter {
}
